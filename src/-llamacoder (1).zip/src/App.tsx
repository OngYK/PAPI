import { useState } from "react";
import { PrecisionPathGame } from "@/components/PrecisionPathGame";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function App() {
  const [bestScore, setBestScore] = useState<number>(0);
  const [showInstructions, setShowInstructions] = useState(true);

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="bg-slate-900 text-white border-b border-slate-800">
        <div className="mx-auto max-w-6xl px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-slate-100">
                PAPI Precision Trainer
              </h1>
              <p className="mt-1 text-sm text-slate-400">
                ICAO Standard Precision Approach Path Indicator Simulation
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="bg-slate-800 text-slate-200 border-slate-700">
                Best: {bestScore.toFixed(1)}%
              </Badge>
              <Button
                variant="secondary"
                className="bg-slate-800 text-slate-200 hover:bg-slate-700"
                onClick={() => setShowInstructions(!showInstructions)}
              >
                {showInstructions ? "Hide Briefing" : "PAPI Briefing"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <PrecisionPathGame onScore={setBestScore} />
          </div>
          <div className="space-y-6">
            {showInstructions && (
              <Card className="bg-slate-900 border-slate-800 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-slate-100">
                    ICAO PAPI Standard
                  </CardTitle>
                  <CardDescription className="text-sm text-slate-400">
                    Understanding the Precision Approach Path Indicator
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-sm text-slate-300">
                  <div className="rounded-lg bg-slate-800 p-4">
                    <p className="font-semibold text-slate-100 mb-2">The PAPI System</p>
                    <p>
                      The PAPI consists of four light units arranged in a horizontal row on both
                      sides of the runway. Each unit projects a beam of light — white above the
                      glide path, red below it. The pilot's position relative to the correct
                      approach angle determines which combination of lights they see.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {[1, 1, 1, 1].map((_, i) => (
                          <div key={i} className="h-6 w-6 rounded-sm bg-white shadow-lg" />
                        ))}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">4 White — Too High</p>
                        <p className="text-xs text-slate-400">Descend</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {[1, 1, 1, 0].map((_, i) => (
                          <div key={i} className={`h-6 w-6 rounded-sm shadow-lg ${i === 3 ? "bg-red-500" : "bg-white"}`} />
                        ))}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">3 White, 1 Red — Slightly High</p>
                        <p className="text-xs text-slate-400">Descend slightly</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {[1, 1, 0, 0].map((_, i) => (
                          <div key={i} className={`h-6 w-6 rounded-sm shadow-lg ${i >= 2 ? "bg-red-500" : "bg-white"}`} />
                        ))}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">2 White, 2 Red — On Glide Path</p>
                        <p className="text-xs text-slate-400">Perfect approach</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {[0, 0, 0, 1].map((_, i) => (
                          <div key={i} className={`h-6 w-6 rounded-sm shadow-lg ${i === 3 ? "bg-white" : "bg-red-500"}`} />
                        ))}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">1 White, 3 Red — Slightly Low</p>
                        <p className="text-xs text-slate-400">Climb slightly</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {[0, 0, 0, 0].map((_, i) => (
                          <div key={i} className="h-6 w-6 rounded-sm bg-red-500 shadow-lg" />
                        ))}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-100">4 Red — Too Low</p>
                        <p className="text-xs text-slate-400">Climb</p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-800 p-4">
                    <p className="font-semibold text-slate-100 mb-2">Pilot Controls</p>
                    <p>
                      Use the <span className="text-amber-400 font-semibold">↑</span> and{" "}
                      <span className="text-amber-400 font-semibold">↓</span> arrow keys to
                      control your aircraft's altitude. Watch the PAPI lights on both sides of
                      the runway to maintain the correct glide path. The goal is to keep the
                      indicator at <span className="text-white font-semibold">2 White, 2 Red</span>{" "}
                      for a perfect approach.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="bg-slate-900 border-slate-800 shadow-xl">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500 text-slate-900">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-100">Pilot's Tip</p>
                    <p className="text-sm text-slate-400">
                      Make small, smooth corrections. Large inputs will cause you to overshoot
                      the glide path.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}