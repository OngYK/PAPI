import { useRef, useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Point {
  x: number;
  y: number;
}

interface AircraftState {
  x: number;
  y: number;
  altitude: number;
  verticalSpeed: number;
}

const GLIDE_SLOPE = 3;
const START_ALTITUDE = 3000;
const APPROACH_DISTANCE = 5;
const ALTITUDE_RANGE = 500;

export function PrecisionPathGame({ onScore }: { onScore: (score: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [aircraft, setAircraft] = useState<AircraftState>({
    x: 50,
    y: 300,
    altitude: START_ALTITUDE,
    verticalSpeed: 0,
  });
  const [papiState, setPapiState] = useState(2);
  const [glidePathDeviation, setGlidePathDeviation] = useState(0);
  const [distanceToRunway, setDistanceToRunway] = useState(APPROACH_DISTANCE);
  const [showHUD, setShowHUD] = useState(false);
  const [showGuide, setShowGuide] = useState(true);
  const [showOnGlideRef, setShowOnGlideRef] = useState(true);
  const [flightPath, setFlightPath] = useState<Point[]>([]);

  const keysPressed = useRef<{ up: boolean; down: boolean }>({ up: false, down: false });

  const drawScene = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Sky gradient
    const skyGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    skyGradient.addColorStop(0, "#0f172a");
    skyGradient.addColorStop(0.4, "#1e293b");
    skyGradient.addColorStop(0.7, "#334155");
    skyGradient.addColorStop(1, "#475569");
    ctx.fillStyle = skyGradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Stars
    ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
    for (let i = 0; i < 50; i++) {
      const x = (i * 37) % canvas.width;
      const y = (i * 53) % (canvas.height * 0.5);
      ctx.fillRect(x, y, 1, 1);
    }

    // Horizon
    const horizonY = canvas.height * 0.65;
    ctx.fillStyle = "#1a1a1a";
    ctx.fillRect(0, horizonY, canvas.width, canvas.height - horizonY);

    // Ground texture
    ctx.fillStyle = "#2d2d2d";
    for (let i = 0; i < 20; i++) {
      const y = horizonY + (i * (canvas.height - horizonY)) / 20;
      ctx.fillRect(0, y, canvas.width, 1);
    }

    // Runway perspective
    const runwayWidth = 300;
    const runwayX = canvas.width / 2 - runwayWidth / 2;
    
    // Runway surface
    ctx.fillStyle = "#3a3a3a";
    ctx.fillRect(runwayX, horizonY, runwayWidth, canvas.height - horizonY);

    // Runway centerline
    ctx.strokeStyle = "rgba(255, 255, 255, 0.4)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, horizonY);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.stroke();

    // Runway edge lines
    ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(runwayX, horizonY);
    ctx.lineTo(runwayX + 20, canvas.height);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(runwayX + runwayWidth, horizonY);
    ctx.lineTo(runwayX + runwayWidth - 20, canvas.height);
    ctx.stroke();

    // Runway markings
    ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
    for (let i = 0; i < 12; i++) {
      const y = horizonY + (i * (canvas.height - horizonY)) / 12;
      const width = runwayWidth * (1 - i / 12) * 0.8;
      ctx.fillRect(canvas.width / 2 - width / 2, y, width, 3);
    }

    // Threshold markings
    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    for (let i = 0; i < 6; i++) {
      const x = runwayX + 20 + i * 20;
      ctx.fillRect(x, horizonY + 5, 10, 3);
    }

    // PAPI lights on BOTH sides
    const papiY = horizonY + 15;
    const leftPapiX = runwayX - 40;
    const rightPapiX = runwayX + runwayWidth + 20;

    // Left PAPI
    for (let i = 0; i < 4; i++) {
      const lightX = leftPapiX + i * 12;
      const isWhite = i < papiState;
      ctx.beginPath();
      ctx.arc(lightX, papiY, 5, 0, Math.PI * 2);
      ctx.fillStyle = isWhite ? "#ffffff" : "#ef4444";
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Glow effect
      ctx.beginPath();
      ctx.arc(lightX, papiY, 8, 0, Math.PI * 2);
      ctx.fillStyle = isWhite ? "rgba(255, 255, 255, 0.2)" : "rgba(239, 68, 68, 0.2)";
      ctx.fill();
    }

    // Right PAPI
    for (let i = 0; i < 4; i++) {
      const lightX = rightPapiX + i * 12;
      const isWhite = i < papiState;
      ctx.beginPath();
      ctx.arc(lightX, papiY, 5, 0, Math.PI * 2);
      ctx.fillStyle = isWhite ? "#ffffff" : "#ef4444";
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Glow effect
      ctx.beginPath();
      ctx.arc(lightX, papiY, 8, 0, Math.PI * 2);
      ctx.fillStyle = isWhite ? "rgba(255, 255, 255, 0.2)" : "rgba(239, 68, 68, 0.2)";
      ctx.fill();
    }

    // Runway edge lights
    for (let i = 0; i < 10; i++) {
      const y = horizonY + (i * (canvas.height - horizonY)) / 10;
      const leftX = runwayX + 5;
      const rightX = runwayX + runwayWidth - 5;
      
      ctx.beginPath();
      ctx.arc(leftX, y, 2, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(rightX, y, 2, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
      ctx.fill();
    }

    // Glide path guide
    if (showGuide) {
      ctx.setLineDash([8, 4]);
      ctx.strokeStyle = "rgba(16, 185, 129, 0.6)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(canvas.width / 2, horizonY);
      ctx.lineTo(canvas.width / 2 - 100, horizonY - 100);
      ctx.stroke();
      ctx.setLineDash([]);

      // Guide arrow
      ctx.fillStyle = "rgba(16, 185, 129, 0.8)";
      ctx.beginPath();
      ctx.moveTo(canvas.width / 2 - 100, horizonY - 100);
      ctx.lineTo(canvas.width / 2 - 90, horizonY - 95);
      ctx.lineTo(canvas.width / 2 - 95, horizonY - 110);
      ctx.closePath();
      ctx.fill();

      // Guide label
      ctx.fillStyle = "rgba(16, 185, 129, 0.8)";
      ctx.font = "12px monospace";
      ctx.textAlign = "left";
      ctx.fillText("GLIDE PATH", canvas.width / 2 - 150, horizonY - 120);
    }

    // On Glide reference
    if (showOnGlideRef) {
      const onGlideY = horizonY - 100;
      const onGlideX = canvas.width / 2 - 100;

      // Reference circle
      ctx.fillStyle = "rgba(16, 185, 129, 0.1)";
      ctx.strokeStyle = "rgba(16, 185, 129, 0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(onGlideX, onGlideY, 15, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Label
      ctx.fillStyle = "rgba(16, 185, 129, 0.9)";
      ctx.font = "bold 14px monospace";
      ctx.textAlign = "center";
      ctx.fillText("ON GLIDE", onGlideX, onGlideY - 25);

      // Aircraft icon
      ctx.fillStyle = "rgba(16, 185, 129, 0.8)";
      ctx.beginPath();
      ctx.moveTo(onGlideX, onGlideY - 8);
      ctx.lineTo(onGlideX + 6, onGlideY + 4);
      ctx.lineTo(onGlideX - 6, onGlideY + 4);
      ctx.closePath();
      ctx.fill();

      // Vertical reference line
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(16, 185, 129, 0.3)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(onGlideX, onGlideY);
      ctx.lineTo(onGlideX, horizonY);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Aircraft position
    const aircraftX = canvas.width / 2;
    const aircraftY = canvas.height * 0.5 + glidePathDeviation * 2;

    // Aircraft nose
    ctx.save();
    ctx.translate(aircraftX, aircraftY);

    // Cockpit frame
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-80, 0);
    ctx.lineTo(-60, -30);
    ctx.lineTo(60, -30);
    ctx.lineTo(80, 0);
    ctx.closePath();
    ctx.stroke();

    // Windshield
    ctx.fillStyle = "rgba(56, 189, 248, 0.1)";
    ctx.beginPath();
    ctx.moveTo(-70, 0);
    ctx.lineTo(-55, -25);
    ctx.lineTo(55, -25);
    ctx.lineTo(70, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Center reference
    ctx.strokeStyle = "rgba(251, 191, 36, 0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -20);
    ctx.lineTo(0, 20);
    ctx.stroke();

    ctx.restore();

    // Flight path trace
    if (flightPath.length > 1) {
      ctx.beginPath();
      ctx.moveTo(flightPath[0].x, flightPath[0].y);
      for (let i = 1; i < flightPath.length; i++) {
        ctx.lineTo(flightPath[i].x, flightPath[i].y);
      }
      ctx.strokeStyle = "rgba(16, 185, 129, 0.5)";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // HUD elements
    if (showHUD) {
      // Altitude tape
      const tapeX = canvas.width - 30;
      const tapeY = 50;
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      ctx.fillRect(tapeX - 15, tapeY - 20, 30, 200);

      ctx.fillStyle = "#ffffff";
      ctx.font = "12px monospace";
      ctx.textAlign = "center";
      for (let i = -4; i <= 4; i++) {
        const alt = Math.round(aircraft.altitude / 100) * 100 + i * 100;
        const y = tapeY + 100 - i * 20;
        ctx.fillText(alt.toString(), tapeX, y);
      }

      // Altitude indicator
      ctx.fillStyle = "#fbbf24";
      ctx.fillRect(tapeX - 15, tapeY + 100 - 10, 30, 20);
      ctx.fillStyle = "#000000";
      ctx.fillText(Math.round(aircraft.altitude).toString(), tapeX, tapeY + 100 + 5);

      // Vertical speed
      const vsX = canvas.width - 60;
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      ctx.fillRect(vsX - 10, tapeY - 20, 20, 200);
      ctx.fillStyle = "#ffffff";
      ctx.fillText("VS", vsX, tapeY - 25);
      ctx.fillStyle = aircraft.verticalSpeed > 0 ? "#10b981" : "#ef4444";
      ctx.fillText(
        `${aircraft.verticalSpeed > 0 ? "+" : ""}${Math.round(aircraft.verticalSpeed)}`,
        vsX,
        tapeY + 100
      );

      // Distance indicator
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      ctx.fillRect(canvas.width / 2 - 100, canvas.height - 40, 200, 30);
      ctx.fillStyle = "#ffffff";
      ctx.font = "14px monospace";
      ctx.fillText(
        `DIST: ${distanceToRunway.toFixed(1)} NM`,
        canvas.width / 2,
        canvas.height - 20
      );
    }
  }, [aircraft, glidePathDeviation, papiState, flightPath, showHUD, distanceToRunway, showGuide, showOnGlideRef]);

  useEffect(() => {
    drawScene();
  }, [drawScene]);

  const calculatePapiState = useCallback((altitude: number): number => {
    const expectedAltitude = (distanceToRunway / APPROACH_DISTANCE) * START_ALTITUDE;
    const deviation = altitude - expectedAltitude;
    const normalizedDeviation = deviation / ALTITUDE_RANGE;

    if (normalizedDeviation < -0.5) return 0;
    if (normalizedDeviation < -0.2) return 1;
    if (normalizedDeviation <= 0.2) return 2;
    if (normalizedDeviation <= 0.5) return 3;
    return 4;
  }, [distanceToRunway]);

  const updateGame = useCallback((deltaTime: number) => {
    setAircraft((prev) => {
      const verticalSpeed = keysPressed.current.up
        ? 500
        : keysPressed.current.down
        ? -500
        : 0;

      const newAltitude = prev.altitude + verticalSpeed * deltaTime;
      const newX = prev.x + 30 * deltaTime;
      const newDistanceToRunway = APPROACH_DISTANCE * (1 - newX / 800);

      const newPapiState = calculatePapiState(newAltitude);
      setPapiState(newPapiState);

      const expectedAltitude = (newDistanceToRunway / APPROACH_DISTANCE) * START_ALTITUDE;
      const deviation = newAltitude - expectedAltitude;
      setGlidePathDeviation(deviation / 100);
      setDistanceToRunway(newDistanceToRunway);

      setFlightPath((prev) => [
        ...prev,
        { x: newX, y: 300 - deviation / 10 },
      ]);

      if (newX >= 800) {
        setIsComplete(true);
        setIsRunning(false);
        setShowHUD(false);
        const finalScore = Math.max(0, 100 - Math.abs(deviation) / 10);
        setScore(finalScore);
        onScore(finalScore);
      }

      return {
        ...prev,
        x: newX,
        y: 300 - deviation / 10,
        altitude: newAltitude,
        verticalSpeed,
      };
    });
  }, [calculatePapiState, onScore]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp") {
        keysPressed.current.up = true;
        e.preventDefault();
      }
      if (e.key === "ArrowDown") {
        keysPressed.current.down = true;
        e.preventDefault();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp") {
        keysPressed.current.up = false;
      }
      if (e.key === "ArrowDown") {
        keysPressed.current.down = false;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  useEffect(() => {
    let animationId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      const deltaTime = (time - lastTime) / 1000;
      lastTime = time;

      if (isRunning) {
        updateGame(deltaTime);
        setTime((prev) => prev + deltaTime);
      }

      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isRunning, updateGame]);

  const startApproach = () => {
    setIsRunning(true);
    setShowHUD(true);
    setTime(0);
    setFlightPath([]);
    setAircraft({
      x: 50,
      y: 300,
      altitude: START_ALTITUDE,
      verticalSpeed: 0,
    });
  };

  const resetGame = () => {
    setIsComplete(false);
    setScore(0);
    setTime(0);
    setIsRunning(false);
    setShowHUD(false);
    setFlightPath([]);
    setPapiState(2);
    setGlidePathDeviation(0);
    setDistanceToRunway(APPROACH_DISTANCE);
    setAircraft({
      x: 50,
      y: 300,
      altitude: START_ALTITUDE,
      verticalSpeed: 0,
    });
    onScore(0);
  };

  const formatTime = (t: number) => {
    const minutes = Math.floor(t / 60);
    const seconds = Math.floor(t % 60);
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  const papiLabels = [
    "4 Red — Too Low",
    "3 Red, 1 White — Slightly Low",
    "2 White, 2 Red — On Glide Path",
    "3 White, 1 Red — Slightly High",
    "4 White — Too High",
  ];

  return (
    <Card className="bg-slate-900 border-slate-800 shadow-xl">
      <CardHeader className="border-b border-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-bold text-slate-100">
              Cockpit View — Final Approach
            </CardTitle>
            <CardDescription className="text-sm text-slate-400">
              Use ↑ and ↓ arrow keys to control altitude
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-slate-800 text-slate-200 border-slate-700">
              Time: {formatTime(time)}
            </Badge>
            <Badge variant="secondary" className="bg-slate-800 text-slate-200 border-slate-700">
              Alt: {Math.round(aircraft.altitude)} ft
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={800}
            height={400}
            className="w-full rounded-xl border-2 border-slate-700 bg-slate-900"
          />
          {!isRunning && !isComplete && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="rounded-xl bg-slate-800/90 px-8 py-6 text-center text-white shadow-xl border border-slate-700 backdrop-blur-sm">
                <p className="text-lg font-semibold">Ready for Approach</p>
                <p className="mt-2 text-sm text-slate-300">
                  Click "Start Approach" to begin your descent
                </p>
                <Button
                  className="mt-4"
                  onClick={startApproach}
                  variant="secondary"
                >
                  Start Approach
                </Button>
              </div>
            </div>
          )}
          {isComplete && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="rounded-xl bg-slate-800/90 px-8 py-6 text-center text-white shadow-xl border border-slate-700 backdrop-blur-sm">
                <p className="text-2xl font-bold text-amber-400">
                  {score.toFixed(1)}% Precision
                </p>
                <p className="mt-2 text-sm text-slate-300">
                  Time: {formatTime(time)} | Final Alt: {Math.round(aircraft.altitude)} ft
                </p>
                <Button
                  className="mt-4"
                  onClick={resetGame}
                  variant="secondary"
                >
                  New Approach
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* PAPI Indicator */}
        <div className="mt-4 rounded-lg bg-slate-800 p-4 border border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex gap-1">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className={`h-8 w-8 rounded-sm shadow-lg transition-colors duration-150 ${
                      i < papiState ? "bg-white" : "bg-red-500"
                    }`}
                  />
                ))}
              </div>
              <div>
                <p className="font-semibold text-slate-100">{papiLabels[papiState]}</p>
                <p className="text-xs text-slate-400">
                  {papiState === 2
                    ? "Perfect — maintain current glide path"
                    : papiState > 2
                    ? "Descend to correct glide path"
                    : "Climb to correct glide path"}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-slate-300">Glide Slope</p>
              <p className="text-2xl font-bold text-amber-400">{GLIDE_SLOPE}°</p>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-lg bg-slate-800 px-4 py-2 border border-slate-700">
              <span className="text-2xl text-amber-400">↑</span>
              <span className="text-sm text-slate-300">Climb</span>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-slate-800 px-4 py-2 border border-slate-700">
              <span className="text-2xl text-amber-400">↓</span>
              <span className="text-sm text-slate-300">Descend</span>
            </div>
            <Button
              variant="secondary"
              className="bg-slate-800 text-slate-200 hover:bg-slate-700"
              onClick={() => setShowGuide(!showGuide)}
            >
              {showGuide ? "Hide Guide" : "Show Guide"}
            </Button>
            <Button
              variant="secondary"
              className="bg-slate-800 text-slate-200 hover:bg-slate-700"
              onClick={() => setShowOnGlideRef(!showOnGlideRef)}
            >
              {showOnGlideRef ? "Hide On Glide" : "Show On Glide"}
            </Button>
          </div>
          <div className="text-sm font-medium text-slate-300">
            Score: <span className="font-bold text-amber-400">{score.toFixed(1)}%</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}